// Lab 3
// Group # 12
// Names: Aleks and Ian
// Date: November 14 2025


import SwiftUI

class GameViewModel: ObservableObject {

    @Published private var model = GameViewModel.createGame()

    private static func createGame() -> MemoryGame {
        // thanksgiving emojis
        let emojis = ["🦃","🌽","🍂","🍁","🥧","🍗"]
        var cards: [Card] = []
        var id = 0

        for emoji in emojis {
            cards.append(Card(id: id, emoji: emoji))
            id += 1
            cards.append(Card(id: id, emoji: emoji))
            id += 1
        }

        cards.shuffle()
        return MemoryGame(cards: cards)
    }

    var cards: [Card] {
        model.cards
    }

    func choose(_ card: Card) {
        model.chooseCard(card)
    }

    func newGame() {
        model = GameViewModel.createGame()
    }
}


