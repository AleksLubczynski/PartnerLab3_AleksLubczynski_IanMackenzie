// Lab 3
// Group # 12
// Names: Aleks and Ian
// Date: November 14 2025


import SwiftUI

struct ContentView: View {

    @StateObject var viewModel = GameViewModel()
    @State private var newGameSpin = false

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    var body: some View {
        VStack {
            Text("Thanksgiving Game")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.orange)
                .padding()

            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(viewModel.cards) { card in
                    CardView(card: card)
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                viewModel.choose(card)
                            }
                        }
                }
            }
            .padding()
            .rotationEffect(.degrees(newGameSpin ? 360 : 0))
            .animation(.easeInOut(duration: 0.4), value: newGameSpin)

            Button("New Game") {
                withAnimation(.easeInOut(duration: 0.4)) {
                    newGameSpin.toggle()
                    viewModel.newGame()
                }
            }
            .padding(.bottom, 20)
            .padding(.horizontal, 30)
            .background(Color.orange)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .background(Color(red: 1.0, green: 0.95, blue: 0.85)) // light beige
        .ignoresSafeArea()
    }
}

struct CardView: View {
    let card: Card

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .fill(card.isFaceUp || card.isMatched ? Color.white : Color.orange.opacity(0.6))

            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.brown, lineWidth: 4)

            if card.isFaceUp || card.isMatched {
                Text(card.isMatched ? "" : card.emoji)
                    .font(.largeTitle)
            }
        }
        .frame(width: 80, height: 80)
        .opacity(card.isMatched ? 0.3 : 1.0)
        .rotation3DEffect(
            .degrees(card.isFaceUp ? 0 : 180),
            axis: (x: 0, y: 1, z: 0)
        )
        .animation(.easeInOut(duration: 0.3), value: card.isFaceUp)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

