// Lab 3
// Group # 12
// Names: Aleks and Ian
// Date: November 14 2025

import Foundation

struct Card: Identifiable {
    let id: Int
    let emoji: String
    var isFaceUp: Bool = false
    var isMatched: Bool = false
}

struct MemoryGame {
    var cards: [Card]
    var indexOfFirstSelected: Int? = nil

    mutating func chooseCard(_ card: Card) {
        if let index = cards.firstIndex(where: { $0.id == card.id }) {

            if cards[index].isMatched { return }
            if cards[index].isFaceUp { return }

            if let firstIndex = indexOfFirstSelected {
                cards[index].isFaceUp = true

                if cards[firstIndex].emoji == cards[index].emoji {
                    cards[firstIndex].isMatched = true
                    cards[index].isMatched = true
                }

                indexOfFirstSelected = nil
            } else {
                for i in cards.indices {
                    if !cards[i].isMatched {
                        cards[i].isFaceUp = false
                    }
                }

                cards[index].isFaceUp = true
                indexOfFirstSelected = index
            }
        }
    }
}

