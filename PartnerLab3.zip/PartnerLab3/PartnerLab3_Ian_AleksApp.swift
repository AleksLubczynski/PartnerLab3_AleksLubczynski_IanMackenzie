// Lab 3
// Group # 12
// Names: Aleks and Ian
// Date: November 14 2025

import SwiftUI

@main
struct PartnerLab3_Ian_AleksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


